library(testthat)
library(lavaan)
library(manCULTA)

test_check("manCULTA")
