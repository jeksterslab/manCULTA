#' @aliases manCULTA-package
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib manCULTA, .registration = TRUE
## usethis namespace: end
NULL
