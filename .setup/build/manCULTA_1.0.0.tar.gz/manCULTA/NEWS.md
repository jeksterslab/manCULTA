# manCULTA 1.0.0

## Docker Hub Tag

* ijapesigan/manculta:2025-07-30-05204520
