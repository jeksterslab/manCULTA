library(testthat)
library(manCULTA)

test_check("manCULTA")
