# manCULTA 0.9.2

## Docker Hub Tag

* ijapesigan/manculta

# manCULTA 0.9.1

* Initial setup
