# manCULTA 0.9.2

* Added functions for Monte Carlo simulation.

# manCULTA 0.9.1

* Initial setup
